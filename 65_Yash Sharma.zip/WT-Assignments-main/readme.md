All the practicals are completed and up to date.<br>
You can refer to these practicals and if any problem persists contact Nitesh Mali/Yash Mishra.
